echo "BACKUP_COUNT checking from child script: $BACKUP_COUNT"
